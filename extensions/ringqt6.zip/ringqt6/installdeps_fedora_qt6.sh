#!/bin/bash
# Install the Qt 6 development packages required to build RingQt6 (Fedora)
# Usage: installdeps_fedora_qt6.sh [core|light|full]    (default: full)

BUILD="${1:-full}"
BASE="gcc-c++ make mesa-libGL-devel mesa-libGLU-devel qt6-qtbase-devel qt6-qtbase-private-devel qt6-qt5compat-devel"
case "$BUILD" in
	core|light)
		PKGS="$BASE" ;;
	full)
		PKGS="$BASE qt6-qtmultimedia-devel qt6-qtserialport-devel qt6-qtpositioning-devel qt6-qtspeech-devel \
		      qt6-qt3d-devel qt6-qtcharts-devel qt6-qtsvg-devel qt6-qtwebengine-devel qt6-qtdeclarative-devel \
		      qt6-qtbase-mysql qt6-qtbase-postgresql qt6-qtbase-odbc" ;;
	*)
		echo "Usage: $0 [core|light|full]"; exit 1 ;;
esac
sudo dnf install -y $PKGS
