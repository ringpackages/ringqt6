#!/bin/bash
# Install Qt 6 (Homebrew) required to build RingQt6 (macOS)
# The "qt" formula contains all the Qt 6 modules (core/light/full builds)

if ! command -v brew >/dev/null 2>&1; then
	echo "Error: Homebrew is required - https://brew.sh"
	exit 1
fi
xcode-select -p >/dev/null 2>&1 || xcode-select --install
brew install qt
