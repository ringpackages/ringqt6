RingQt6 - Linux/macOS build scripts
===================================

The scripts in this folder are copied to the RingQt6 extension folder (ring/extensions/ringqt6)
by the `ringqt6` package. Run them from any folder.

Requirements
============

* Ring built from source (libring.so in /usr/lib on Linux, ring/lib/libring.dylib on macOS)
* Qt 6 (6.4 or later, tested with Qt 6.12) and a C++17 compiler

(1) Install the dependencies

    ./installdeps_ubuntu_qt6.sh [core|light|full]     Ubuntu/Debian
    ./installdeps_fedora_qt6.sh [core|light|full]     Fedora
    ./installdeps_macos_qt6.sh                        macOS (Homebrew)

(2) Build the shared library (copied to ring/lib)

    Linux                          macOS                           Output
    ./buildgcc_core_qt6.sh         ./buildclang_core_qt6.sh        libringqt_core   (Qt Core)
    ./buildgcc_light_qt6.sh        ./buildclang_light_qt6.sh       libringqt_light  (Core + GUI + Widgets)
    ./buildgcc_qt6.sh              ./buildclang_qt6.sh             libringqt        (Full - No Bluetooth)

Use the QMAKE environment variable to select a specific Qt 6 installation, for example

    QMAKE=$HOME/Qt/6.12.0/gcc_64/bin/qmake ./buildgcc_qt6.sh

Then use `load "guilib.ring"` (or lightguilib.ring/qtcore.ring) as usual.

(3) Generate the C++ code (optional)

The generated code (cpp folder) and the Ring classes are already provided.
After modifying the classes/*.cf files run

    ./gencode_core_qt6.sh
    ./gencode_light_qt6.sh
    ./gencode_nobluetooth_qt6.sh
